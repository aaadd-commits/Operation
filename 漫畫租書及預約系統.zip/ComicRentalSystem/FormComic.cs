﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComicRentalSystem
{
    public partial class FormComic : Form
    {
        private List<Comic> comics;
        public FormComic()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            LoadComics();
            cmbFilterType.Items.AddRange(new string[] { "", "漫畫編號", "書名", "作者", "庫存數量", "類型" });
            cmbFilterType.SelectedIndex = 0;
        }

        private void LoadComics()
        {
   
            comics = DataStore.Comics;  // 指向共用漫畫清單
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = comics;
        }
        //查詢
        private readonly Dictionary<string, Func<Comic, string, bool>> filterOptions = new Dictionary<string, Func<Comic, string, bool>>
        {
            { "漫畫編號", (c, keyword) => c.comicID.Contains(keyword) },
            { "書名",     (c, keyword) => c.Title.Contains(keyword) },
            { "作者",     (c, keyword) => c.Author.Contains(keyword) },
            { "庫存數量", (c, keyword) => c.Count.ToString().Contains(keyword) },
            { "類型",     (c, keyword) => c.Type.Contains(keyword) }
        };

        //排序
        private readonly Dictionary<string, Func<Comic, object>> sortOptions = new Dictionary<string, Func<Comic, object>>
        {
            { "漫畫編號", c => c.comicID },
            { "書名", c => c.Title },
            { "作者", c => c.Author },
            { "庫存數量", c => c.Count },
            { "類型", c => c.Type }
        };
        private void btnAddToRent_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                Comic selected = (Comic)dataGridView1.CurrentRow.DataBoundItem;
                if (selected.Count > 0)
                {
                    // 判斷是否已在選擇清單
                    bool alreadyAdded = DataStore.SelectedComics.Any(c => c.comicID == selected.comicID);
                    if (alreadyAdded)
                    {
                        MessageBox.Show("此漫畫已加入租借清單！");
                        return;
                    }

                    DataStore.SelectedComics.Add(selected);
                    MessageBox.Show($"已加入：{selected.Title}");
                    DataStore.SaveSelectedComicsToJson();
                }
                else
                {
                    MessageBox.Show("此漫畫無庫存，無法加入！");
                }
            }
        }

        private void btnGoToRent_Click(object sender, EventArgs e)
        {
            FormRent rentForm = new FormRent(this);  // 傳入自己給租借畫面
            rentForm.ShowDialog();
        }
        public void RefreshComicList()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = DataStore.Comics;
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            string filterType = cmbFilterType.SelectedItem?.ToString();
            bool doSort = checkBox1.Checked;
            List<Comic> result = DataStore.Comics;

            // 有輸入關鍵字與篩選欄位時才做篩選
            if (!string.IsNullOrEmpty(keyword) && !string.IsNullOrEmpty(filterType) && filterOptions.ContainsKey(filterType))
            {
                result = result.Where(c => filterOptions[filterType](c, keyword)).ToList();
            }
            else if (!string.IsNullOrEmpty(keyword))
            {
                // 模糊搜尋（全部欄位都比對）
                result = result.Where(c =>
                    c.comicID.Contains(keyword) ||
                    c.Title.Contains(keyword) ||
                    c.Author.Contains(keyword) ||
                    c.Count.ToString().Contains(keyword) ||
                    c.Type.Contains(keyword)
                ).ToList();
            }


            if (doSort && sortOptions.ContainsKey(filterType))
            {
                result = result.OrderBy(sortOptions[filterType]).ToList();
            }
            dataGridView1.DataSource = result;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnAddToFavorite_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("請先選取一筆漫畫資料！");
                return;
            }

            string comicTitle = dataGridView1.CurrentRow.Cells["comicID"].Value.ToString();
            var comic = DataStore.Comics.FirstOrDefault(c => c.comicID == comicTitle);
            if (comic == null)
            {
                MessageBox.Show("找不到選取的漫畫！");
                return;
            }
            // 檢查是否已收藏
            bool alreadyFavorited = DataStore.FavoriteRecords
                .Any(f => f.MemberID == DataStore.CurrentMemberID && f.ComicID == comic.comicID);

            if (alreadyFavorited)
            {
                MessageBox.Show("你已經收藏過這本漫畫！");
                return;
            }

            // 加入收藏
            DataStore.FavoriteRecords.Add(new FavoriteRecord
            {
                MemberID = DataStore.CurrentMemberID,
                ComicID = comic.comicID,
                FavoriteDate = DateTime.Now
            });

            MessageBox.Show("成功加入收藏清單！");
            DataStore.SaveFavoriteRecordsToJson();
        }
    }
}
