﻿namespace ComicRentalSystem
{
    partial class FormMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAddMember = new Button();
            txtName = new TextBox();
            txtMemberID = new TextBox();
            label3 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btnAddMember
            // 
            btnAddMember.BackColor = SystemColors.ControlDark;
            btnAddMember.ForeColor = SystemColors.ControlText;
            btnAddMember.Location = new Point(127, 293);
            btnAddMember.Margin = new Padding(4);
            btnAddMember.Name = "btnAddMember";
            btnAddMember.Size = new Size(332, 71);
            btnAddMember.TabIndex = 5;
            btnAddMember.TabStop = false;
            btnAddMember.Text = "新增會員";
            btnAddMember.UseVisualStyleBackColor = false;
            btnAddMember.Click += btnAddMember_Click;
            // 
            // txtName
            // 
            txtName.ForeColor = SystemColors.MenuText;
            txtName.Location = new Point(269, 185);
            txtName.Margin = new Padding(4);
            txtName.Name = "txtName";
            txtName.Size = new Size(190, 39);
            txtName.TabIndex = 2;
            // 
            // txtMemberID
            // 
            txtMemberID.ForeColor = SystemColors.MenuText;
            txtMemberID.Location = new Point(269, 82);
            txtMemberID.Margin = new Padding(4);
            txtMemberID.Name = "txtMemberID";
            txtMemberID.Size = new Size(190, 39);
            txtMemberID.TabIndex = 1;
            // 
            // label3
            // 
            label3.Font = new Font("微軟正黑體", 12F);
            label3.Location = new Point(127, 86);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(134, 35);
            label3.TabIndex = 7;
            label3.Text = "會員編號 :";
            // 
            // label2
            // 
            label2.Font = new Font("微軟正黑體", 12F);
            label2.Location = new Point(127, 188);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(87, 35);
            label2.TabIndex = 8;
            label2.Text = "姓名 :";
            // 
            // FormMember
            // 
            AutoScaleDimensions = new SizeF(14F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(606, 414);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(txtMemberID);
            Controls.Add(txtName);
            Controls.Add(btnAddMember);
            Font = new Font("微軟正黑體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            Margin = new Padding(4);
            MaximizeBox = false;
            Name = "FormMember";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "建立會員";
            Load += FormMember_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnAddMember;
        private TextBox txtName;
        private TextBox txtMemberID;
        private Label label3;
        private Label label2;
    }
}