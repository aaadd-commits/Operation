﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;

namespace ComicRentalSystem
{
    public partial class FormReserve : Form
    {
        public FormReserve()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            comboSortBy.Items.AddRange(new string[]
            {
                "漫畫編號",
                "漫畫名稱",
                "收藏日期",
                "庫存數量"
            });
            comboSortBy.SelectedIndex = 0; // 預設選第一項
            RefreshFavoriteList();
        }
        private void RefreshFavoriteList()
        {
            // 基本清單：目前會員的收藏漫畫
            var favoriteList = DataStore.FavoriteRecords
                .Where(f => f.MemberID == DataStore.CurrentMemberID)
                .Join(
                    DataStore.Comics,
                    fav => fav.ComicID,
                    comic => comic.comicID,
                    (fav, comic) => new
                    {
                        漫畫編號 = fav.ComicID,
                        書名 = comic.Title,
                        收藏日期 = fav.FavoriteDate.Date,
                        收藏時間 = fav.FavoriteDate.ToString("HH:mm"),
                        庫存數量 = comic.Count
                    });

            // 是否啟用排序（搭配 checkbox）
            if (checkBox1.Checked)
            {
                favoriteList = comboSortBy.SelectedItem?.ToString() switch
                {
                    "漫畫名稱" => favoriteList.OrderBy(f => f.書名),
                    "收藏日期" => favoriteList.OrderByDescending(f => f.收藏日期),
                    "庫存數量" => favoriteList.OrderByDescending(f => f.庫存數量),
                    _ => favoriteList.OrderBy(f => f.漫畫編號) // 預設漫畫編號排序
                };
            }

            dataGridView1.DataSource = favoriteList.ToList(); // 最後統一轉 List 並指定資料來源
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // 判斷是否點到按鈕列
            if (dataGridView1.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                // 取得漫畫編號
                string comicID = dataGridView1.Rows[e.RowIndex].Cells["漫畫編號"].Value.ToString();

                // 確認是否要取消收藏
                DialogResult result = MessageBox.Show("確定要取消收藏這本漫畫嗎？", "確認", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    // 從收藏記錄中移除
                    var recordToRemove = DataStore.FavoriteRecords
                        .FirstOrDefault(f => f.MemberID == DataStore.CurrentMemberID && f.ComicID == comicID);

                    if (recordToRemove != null)
                    {
                        DataStore.FavoriteRecords.Remove(recordToRemove);
                        MessageBox.Show("已取消收藏！");
                        DataStore.SaveFavoriteRecordsToJson();
                        RefreshFavoriteList(); // 重新載入收藏列表
                    }
                    else
                    {
                        MessageBox.Show("找不到收藏記錄！");
                    }
                }
            }
        }

        private void btnAddToRent_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                string comicID = dataGridView1.CurrentRow.Cells["漫畫編號"].Value.ToString();
                var comicToAdd = DataStore.Comics.FirstOrDefault(c => c.comicID == comicID);

                if (comicToAdd != null)
                {
                    if (comicToAdd.Count <= 0)
                    {
                        MessageBox.Show("此漫畫無庫存，無法加入！");
                        return;
                    }

                    if (DataStore.SelectedComics.Any(c => c.comicID == comicID))
                    {
                        MessageBox.Show("此漫畫已加入租借清單！");
                        return;
                    }
                    DataStore.SelectedComics.Add(comicToAdd);
                    MessageBox.Show($"已加入租借清單：{comicToAdd.Title}");
                    DataStore.SaveSelectedComicsToJson();
                }
                else
                {
                    MessageBox.Show("找不到該漫畫資料！");
                }
            }
            else
            {
                MessageBox.Show("請先選取一筆漫畫資料！");
            }
        }
      

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                RefreshFavoriteList(); // 立即排序
            }
        }

        private void comboSortBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                RefreshFavoriteList();
            }
        }
    }
}
