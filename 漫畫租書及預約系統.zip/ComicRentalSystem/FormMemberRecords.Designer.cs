﻿namespace ComicRentalSystem
{
    partial class FormMemberRecords
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label2 = new Label();
            lblMemberName = new Label();
            label1 = new Label();
            txtNewName = new TextBox();
            btnChangeName = new Button();
            btnConfirmName = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(38, 65);
            dataGridView1.Margin = new Padding(4);
            dataGridView1.MultiSelect = false;
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(677, 391);
            dataGridView1.TabIndex = 3;
            dataGridView1.TabStop = false;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label2
            // 
            label2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(38, 23);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(133, 35);
            label2.TabIndex = 5;
            label2.Text = "會員姓名：";
            label2.Click += label2_Click;
            // 
            // lblMemberName
            // 
            lblMemberName.BackColor = SystemColors.Control;
            lblMemberName.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMemberName.ForeColor = SystemColors.ControlText;
            lblMemberName.Location = new Point(179, 19);
            lblMemberName.Margin = new Padding(4, 0, 4, 0);
            lblMemberName.Name = "lblMemberName";
            lblMemberName.Size = new Size(255, 39);
            lblMemberName.TabIndex = 6;
            lblMemberName.TextAlign = ContentAlignment.MiddleLeft;
            lblMemberName.Click += lblMemberName_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(38, 23);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(133, 35);
            label1.TabIndex = 7;
            label1.Text = "新姓名：";
            label1.Visible = false;
            // 
            // txtNewName
            // 
            txtNewName.Location = new Point(179, 20);
            txtNewName.Name = "txtNewName";
            txtNewName.Size = new Size(255, 39);
            txtNewName.TabIndex = 8;
            txtNewName.Visible = false;
            // 
            // btnChangeName
            // 
            btnChangeName.Location = new Point(451, 19);
            btnChangeName.Name = "btnChangeName";
            btnChangeName.Size = new Size(156, 39);
            btnChangeName.TabIndex = 9;
            btnChangeName.TabStop = false;
            btnChangeName.Text = "變更姓名";
            btnChangeName.UseVisualStyleBackColor = true;
            btnChangeName.Click += btnChangeName_Click;
            // 
            // btnConfirmName
            // 
            btnConfirmName.Location = new Point(451, 19);
            btnConfirmName.Name = "btnConfirmName";
            btnConfirmName.Size = new Size(156, 39);
            btnConfirmName.TabIndex = 10;
            btnConfirmName.TabStop = false;
            btnConfirmName.Text = "確認變更";
            btnConfirmName.UseVisualStyleBackColor = true;
            btnConfirmName.Visible = false;
            btnConfirmName.Click += btnConfirmName_Click;
            // 
            // FormMemberRecords
            // 
            AutoScaleDimensions = new SizeF(14F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(757, 489);
            Controls.Add(btnConfirmName);
            Controls.Add(btnChangeName);
            Controls.Add(txtNewName);
            Controls.Add(label1);
            Controls.Add(lblMemberName);
            Controls.Add(label2);
            Controls.Add(dataGridView1);
            Font = new Font("微軟正黑體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            ForeColor = SystemColors.ControlText;
            Margin = new Padding(4);
            MaximizeBox = false;
            Name = "FormMemberRecords";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "會員紀錄";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView dataGridView1;
        private Label label2;
        private Label lblMemberName;
        private Label label1;
        private TextBox txtNewName;
        private Button btnChangeName;
        private Button btnConfirmName;
    }
}