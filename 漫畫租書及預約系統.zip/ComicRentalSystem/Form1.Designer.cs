﻿namespace ComicRentalSystem
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnReserve = new Button();
            btnComicManage = new Button();
            btnMemberManage = new Button();
            btnRent = new Button();
            btnReturn = new Button();
            SuspendLayout();
            // 
            // btnReserve
            // 
            btnReserve.Font = new Font("微軟正黑體", 12F);
            btnReserve.Location = new Point(178, 195);
            btnReserve.Margin = new Padding(6);
            btnReserve.Name = "btnReserve";
            btnReserve.Size = new Size(208, 70);
            btnReserve.TabIndex = 3;
            btnReserve.TabStop = false;
            btnReserve.Text = "收藏清單";
            btnReserve.UseVisualStyleBackColor = true;
            btnReserve.Click += btnReserve_Click;
            // 
            // btnComicManage
            // 
            btnComicManage.Font = new Font("微軟正黑體", 12F);
            btnComicManage.Location = new Point(178, 277);
            btnComicManage.Margin = new Padding(6);
            btnComicManage.Name = "btnComicManage";
            btnComicManage.Size = new Size(208, 70);
            btnComicManage.TabIndex = 4;
            btnComicManage.TabStop = false;
            btnComicManage.Text = "查詢漫畫";
            btnComicManage.UseVisualStyleBackColor = true;
            btnComicManage.Click += btnComicManage_Click;
            // 
            // btnMemberManage
            // 
            btnMemberManage.Font = new Font("微軟正黑體", 12F);
            btnMemberManage.Location = new Point(123, 359);
            btnMemberManage.Margin = new Padding(6);
            btnMemberManage.Name = "btnMemberManage";
            btnMemberManage.RightToLeft = RightToLeft.No;
            btnMemberManage.Size = new Size(318, 70);
            btnMemberManage.TabIndex = 5;
            btnMemberManage.TabStop = false;
            btnMemberManage.Text = "查看會員資訊與紀錄";
            btnMemberManage.UseVisualStyleBackColor = true;
            btnMemberManage.Click += btnMemberManage_Click;
            // 
            // btnRent
            // 
            btnRent.Font = new Font("微軟正黑體", 12F);
            btnRent.Location = new Point(178, 31);
            btnRent.Margin = new Padding(6);
            btnRent.Name = "btnRent";
            btnRent.Size = new Size(208, 70);
            btnRent.TabIndex = 1;
            btnRent.TabStop = false;
            btnRent.Text = "租借漫畫";
            btnRent.UseVisualStyleBackColor = true;
            btnRent.Click += btnRent_Click;
            // 
            // btnReturn
            // 
            btnReturn.Font = new Font("微軟正黑體", 12F);
            btnReturn.Location = new Point(178, 113);
            btnReturn.Margin = new Padding(6);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(208, 70);
            btnReturn.TabIndex = 2;
            btnReturn.TabStop = false;
            btnReturn.Text = "歸還漫畫";
            btnReturn.UseVisualStyleBackColor = true;
            btnReturn.Click += btnReturn_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(19F, 40F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(578, 444);
            Controls.Add(btnReturn);
            Controls.Add(btnRent);
            Controls.Add(btnMemberManage);
            Controls.Add(btnComicManage);
            Controls.Add(btnReserve);
            Font = new Font("微軟正黑體", 16F, FontStyle.Regular, GraphicsUnit.Point, 136);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(6);
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "漫畫租借系統";
            ResumeLayout(false);
        }

        #endregion
        private Button btnReserve;
        private Button btnComicManage;
        private Button btnMemberManage;
        private Button btnRent;
        private Button btnReturn;
    }
}
