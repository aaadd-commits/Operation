namespace ComicRentalSystem
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//�����վ�form�j�p
        }

        private void btnRent_Click(object sender, EventArgs e)
        {
            FormRent formRent = new FormRent();
            formRent.ShowDialog();  // �}�ү��ѵ����A�ҺA����
        }
        private void btnReturn_Click_1(object sender, EventArgs e)
        {
            FormReturn formReturn = new FormReturn();
            // �p�G�Q�ΦP�@�ӵ����Ϥ����ٮѡA�i�[�ѼƩ��ݩʳ]�w
            formReturn.ShowDialog();
        }
        

        private void btnReserve_Click(object sender, EventArgs e)
        {
            FormReserve formReserve = new FormReserve();
            formReserve.ShowDialog();
        }

        private void btnComicManage_Click(object sender, EventArgs e)
        {
            FormComic formComic = new FormComic();
            formComic.ShowDialog();
        }


        private void btnMemberManage_Click(object sender, EventArgs e)
        {
            if (DataStore.Members == null || DataStore.Members.Count == 0)
            {
                MessageBox.Show("�|�����|����ơA�Х��إ߷|���C");
                FormMember formMember = new FormMember();
                formMember.ShowDialog();
            }
            else
            {
                FormMemberRecords formRecords = new FormMemberRecords();
                formRecords.ShowDialog();
            }
        }
    }
}
