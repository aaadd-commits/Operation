﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace ComicRentalSystem
{
    public partial class FormMember : Form
    {
        public FormMember()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            string memberId = txtMemberID.Text.Trim();
            string name = txtName.Text.Trim();

            if (string.IsNullOrEmpty(memberId))
            {
                MessageBox.Show("請輸入會員編號！");
                return;
            }

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("請輸入姓名！");
                return;
            }

            // 檢查會員編號是否已存在
            bool exists = DataStore.Members.Any(m => m.MemberID == memberId);
            if (exists)
            {
                MessageBox.Show("此會員編號已存在！");
                return;
            }

            var newMember = new Member
            {
                MemberID = memberId,
                Name = name
            };
            DataStore.Members.Add(newMember);
            DataStore.CurrentMemberID = newMember.MemberID;


            MessageBox.Show("會員新增成功！");
            DataStore.SaveMembersToJson();
            this.Close();
        }

        private void FormMember_Load(object sender, EventArgs e)
        {

        }
    }
}
