﻿namespace ComicRentalSystem
{
    partial class FormRent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            button1 = new Button();
            btnRemoveSelected_Click = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(13, 13);
            dataGridView1.Margin = new Padding(4);
            dataGridView1.MultiSelect = false;
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(816, 386);
            dataGridView1.TabIndex = 1;
            dataGridView1.TabStop = false;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button1
            // 
            button1.Location = new Point(13, 407);
            button1.Margin = new Padding(4);
            button1.Name = "button1";
            button1.Size = new Size(404, 56);
            button1.TabIndex = 2;
            button1.TabStop = false;
            button1.Text = "租借";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnRemoveSelected_Click
            // 
            btnRemoveSelected_Click.Location = new Point(425, 407);
            btnRemoveSelected_Click.Margin = new Padding(4);
            btnRemoveSelected_Click.Name = "btnRemoveSelected_Click";
            btnRemoveSelected_Click.Size = new Size(404, 56);
            btnRemoveSelected_Click.TabIndex = 3;
            btnRemoveSelected_Click.TabStop = false;
            btnRemoveSelected_Click.Text = "移除";
            btnRemoveSelected_Click.UseVisualStyleBackColor = true;
            btnRemoveSelected_Click.Click += btnRemoveSelected_Click_Click;
            // 
            // FormRent
            // 
            AutoScaleDimensions = new SizeF(14F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(843, 469);
            Controls.Add(btnRemoveSelected_Click);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Font = new Font("微軟正黑體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            Margin = new Padding(4);
            MaximizeBox = false;
            Name = "FormRent";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "租借漫畫";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private DataGridView dataGridView1;
        private Button button1;
        private Button btnRemoveSelected_Click;
    }
}