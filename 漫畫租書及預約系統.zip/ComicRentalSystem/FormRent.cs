﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComicRentalSystem
{
    public partial class FormRent : Form
    {
        private FormComic _comicForm;

        public FormRent()  
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Load += FormRent_Load;
        }
        public FormRent(FormComic comicForm)
        {
            InitializeComponent();
            _comicForm = comicForm;
            this.Load += FormRent_Load;
        }
        private void FormRent_Load(object sender, EventArgs e)
        {
            RefreshSelectedComics();
        }
        private void RefreshSelectedComics()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = DataStore.SelectedComics;
            dataGridView1.CurrentCell = null;  // 取消藍色選取
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime rentDate;
            // 檢查會員是否存在
            var member = DataStore.Members.FirstOrDefault(m => m.MemberID == DataStore.CurrentMemberID);
            if (DataStore.Members == null || DataStore.Members.Count == 0)
            {
                MessageBox.Show("尚未有會員資料，請先建立會員。");
                FormMember formMember = new FormMember();
                formMember.ShowDialog();
            }
            else if(dataGridView1.Rows.Count != 0)
            { 
            // 檢查是否有重複租借
            var alreadyRented = DataStore.RentalRecords
                    .Where(r => r.MemberID == DataStore.CurrentMemberID)
                    .Select(r => r.ComicID)
                    .ToHashSet();

            var duplicateTitles = DataStore.SelectedComics
                .Where(c => alreadyRented.Contains(c.comicID))
                .Select(c => c.Title)
                .ToList();

            if (duplicateTitles.Count > 0)
            {
                MessageBox.Show($"以下漫畫已經租借過，無法重複租借：\n{string.Join("\n", duplicateTitles)}");
                return;
            }
            // 減少庫存
            foreach (var selectedComic in DataStore.SelectedComics)
            {
                var comicInStore = DataStore.Comics.FirstOrDefault(c => c.comicID == selectedComic.comicID);
                if (comicInStore != null && comicInStore.Count > 0)
                {
                    comicInStore.Count -= 1;
                }

                rentDate = selectedComic.comicID == "C001"? DateTime.Now.AddDays(-10)
                : selectedComic.comicID == "C003"? DateTime.Now.AddDays(-12)
                : DateTime.Now;

                // 記錄租借紀錄
                DataStore.RentalRecords.Add(new RentalRecord
                {
                    MemberID = DataStore.CurrentMemberID,
                    ComicID = selectedComic.comicID,
                    RentDate = rentDate
                });

            }

            DataStore.SelectedComics.Clear();

            MessageBox.Show("租借完成！");
            // 租借成功、庫存減少後
            DataStore.SaveComicsToJson();  // 庫存更新儲存
            DataStore.SaveRentalRecordsToJson(); //租借記錄儲存
            if (_comicForm != null)
            {
                _comicForm.RefreshComicList();  // 你要在 FormComic 裡定義這個方法
            }
            this.Close();
        }
            else
            {
                MessageBox.Show("目前沒有租借紀錄，無法進行租借！");
                return;  // 不繼續租借流程
            }
    }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtMemberID_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRemoveSelected_Click_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                Comic selected = (Comic)dataGridView1.CurrentRow.DataBoundItem;

                // 從租借清單中移除這本漫畫
                DataStore.SelectedComics.RemoveAll(c => c.comicID == selected.comicID);

                // 更新 DataGridView
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = DataStore.SelectedComics;

                MessageBox.Show($"已從租借清單中移除：{selected.Title}");
                DataStore.SaveSelectedComicsToJson();
            }
            else
            {
                MessageBox.Show("請先選擇要移除的漫畫");
            }
        }

    }
}
