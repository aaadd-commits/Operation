﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComicRentalSystem
{
    public class RentalRecord
    {
        public string MemberID { get; set; } //會員ID
        public string ComicID { get; set; } //漫畫ID 
        public DateTime RentDate { get; set; } //租借日期
        public int RentalDays { get; set; } = 7;  // 預設租借 7 天

        public DateTime DueDate => RentDate.AddDays(RentalDays); //到期日

        public int RemainingDays => (DueDate - DateTime.Now).Days; //剩餘天數
        public DateTime? ReturnDate { get; set; }  // 用來記錄是否已歸還的日期
    }

}
