﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComicRentalSystem
{
    public partial class FormMemberRecords : Form
    {
        private string _memberId;
        public FormMemberRecords()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            display_data();
        }


        private void display_data()
        {
            //顯示會員名稱
            var member = DataStore.Members.FirstOrDefault();
            if (member != null)
            {
                lblMemberName.Text = member.Name;
            }

            // 查詢租借紀錄
            var memberRecords = DataStore.RentalRecords
                .Select(r => new
                {
                    書名 = DataStore.Comics.FirstOrDefault(c => c.comicID == r.ComicID)?.Title ?? "(未知)",
                    租借日 = r.RentDate.ToString("yyyy/MM/dd"),
                    歸還日 = r.DueDate.ToString("yyyy/MM/dd"),
                    剩餘天數 = Math.Max(0, r.RemainingDays)
                }).ToList();

            dataGridView1.DataSource = memberRecords;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblMemberName_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnChangeName_Click(object sender, EventArgs e)
        {
            txtNewName.Visible = true;
            btnConfirmName.Visible = true;
            label1.Visible = true;
            txtNewName.Text = ""; // 清空之前的輸入
            txtNewName.Focus();
        }

        private void btnConfirmName_Click(object sender, EventArgs e)
        {
            string newName = txtNewName.Text.Trim();
            if (string.IsNullOrEmpty(newName))
            {
                MessageBox.Show("請輸入新姓名！");
                return;
            }

            var member = DataStore.Members.FirstOrDefault();
            if (member != null)
            {
                member.Name = newName;
                DataStore.SaveMembersToJson();
                lblMemberName.Text = member.Name;

                MessageBox.Show("姓名已更新！");
            }

            // 隱藏輸入框與按鈕
            txtNewName.Visible = false;
            btnConfirmName.Visible = false;
            label1.Visible = false;
        }
    }
}
