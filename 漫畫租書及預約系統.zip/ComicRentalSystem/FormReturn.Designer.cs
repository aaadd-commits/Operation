﻿namespace ComicRentalSystem
{
    partial class FormReturn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnRemoveSelected_Click = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(38, 33);
            dataGridView1.Margin = new Padding(4);
            dataGridView1.MultiSelect = false;
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(819, 373);
            dataGridView1.TabIndex = 1;
            dataGridView1.TabStop = false;
            dataGridView1.MouseUp += dataGridView1_MouseUp;
            // 
            // btnRemoveSelected_Click
            // 
            btnRemoveSelected_Click.Location = new Point(254, 414);
            btnRemoveSelected_Click.Margin = new Padding(4);
            btnRemoveSelected_Click.Name = "btnRemoveSelected_Click";
            btnRemoveSelected_Click.Size = new Size(381, 47);
            btnRemoveSelected_Click.TabIndex = 9;
            btnRemoveSelected_Click.TabStop = false;
            btnRemoveSelected_Click.Text = "歸還";
            btnRemoveSelected_Click.UseVisualStyleBackColor = true;
            btnRemoveSelected_Click.Click += btnRemoveSelected_Click_Click;
            // 
            // FormReturn
            // 
            AutoScaleDimensions = new SizeF(14F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(893, 474);
            Controls.Add(btnRemoveSelected_Click);
            Controls.Add(dataGridView1);
            Font = new Font("微軟正黑體", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            MaximizeBox = false;
            Name = "FormReturn";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "漫畫歸還";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private DataGridView dataGridView1;
        private Button btnRemoveSelected_Click;
    }
}