﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;


namespace ComicRentalSystem
{
    internal class DataStore
    {
        private static string filePath = "comics.json";
        private static string memberFilePath = "members.json";
        private static string selectedComicsFilePath = "selected_comics.json";
        private static string rentalRecordsFilePath = "rental_records.json";
        private static string favoriteRecordsFilePath = "favorite_records.json";

        // 泛型讀檔
        private static List<T> LoadFromJson<T>(string path)
        {
            if (!File.Exists(path))
                return new List<T>();

            string json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();
        }

        // 泛型寫檔
        private static void SaveToJson<T>(string path, List<T> list)
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            string json = JsonSerializer.Serialize(list, options);
            File.WriteAllText(path, json);
        }

        public static void LoadComicsFromJson()
        {
            Comics = LoadFromJson<Comic>(filePath);
        }
        public static void SaveComicsToJson()
        {
            SaveToJson(filePath, Comics);
        }

        public static void LoadMembersFromJson()
        {
            Members = LoadFromJson<Member>(memberFilePath);
        }
        public static void SaveMembersToJson()
        {
            SaveToJson(memberFilePath, Members);
        }

        public static void LoadSelectedComicsFromJson()
        {
            SelectedComics = LoadFromJson<Comic>(selectedComicsFilePath);
        }
        public static void SaveSelectedComicsToJson()
        {
            SaveToJson(selectedComicsFilePath, SelectedComics);
        }

        public static void LoadRentalRecordsFromJson()
        {
            RentalRecords = LoadFromJson<RentalRecord>(rentalRecordsFilePath);
        }
        public static void SaveRentalRecordsToJson()
        {
            SaveToJson(rentalRecordsFilePath, RentalRecords);
        }

        public static void LoadFavoriteRecordsFromJson()
        {
            FavoriteRecords = LoadFromJson<FavoriteRecord>(favoriteRecordsFilePath);
        }
        public static void SaveFavoriteRecordsToJson()
        {
            SaveToJson(favoriteRecordsFilePath, FavoriteRecords);
        }

        public static List<Comic> Comics = new List<Comic>();
        public static List<Comic> SelectedComics = new List<Comic>();
        public static List<Member> Members = new List<Member>();
        public static List<RentalRecord> RentalRecords = new List<RentalRecord>();
        public static string CurrentMemberID = null;
        public static List<FavoriteRecord> FavoriteRecords = new List<FavoriteRecord>();
    }
}
