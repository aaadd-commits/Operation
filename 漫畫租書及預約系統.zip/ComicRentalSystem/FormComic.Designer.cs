﻿namespace ComicRentalSystem
{
    partial class FormComic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAddToRent = new Button();
            btnGoToRent = new Button();
            dataGridView1 = new DataGridView();
            txtSearch = new TextBox();
            cmbFilterType = new ComboBox();
            btnSearch = new Button();
            label2 = new Label();
            checkBox1 = new CheckBox();
            btnAddToFavorite = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnAddToRent
            // 
            btnAddToRent.Location = new Point(13, 407);
            btnAddToRent.Margin = new Padding(4);
            btnAddToRent.Name = "btnAddToRent";
            btnAddToRent.Size = new Size(280, 56);
            btnAddToRent.TabIndex = 0;
            btnAddToRent.TabStop = false;
            btnAddToRent.Text = "加入租借清單";
            btnAddToRent.UseVisualStyleBackColor = true;
            btnAddToRent.Click += btnAddToRent_Click;
            // 
            // btnGoToRent
            // 
            btnGoToRent.Location = new Point(584, 407);
            btnGoToRent.Margin = new Padding(4);
            btnGoToRent.Name = "btnGoToRent";
            btnGoToRent.Size = new Size(275, 56);
            btnGoToRent.TabIndex = 1;
            btnGoToRent.TabStop = false;
            btnGoToRent.Text = "跳轉到租書畫面";
            btnGoToRent.UseVisualStyleBackColor = true;
            btnGoToRent.Click += btnGoToRent_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(13, 57);
            dataGridView1.Margin = new Padding(4);
            dataGridView1.MultiSelect = false;
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(846, 342);
            dataGridView1.TabIndex = 2;
            dataGridView1.TabStop = false;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(193, 10);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(235, 39);
            txtSearch.TabIndex = 3;
            // 
            // cmbFilterType
            // 
            cmbFilterType.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbFilterType.FormattingEnabled = true;
            cmbFilterType.Location = new Point(444, 10);
            cmbFilterType.Name = "cmbFilterType";
            cmbFilterType.Size = new Size(175, 38);
            cmbFilterType.TabIndex = 4;
            cmbFilterType.TabStop = false;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(642, 9);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(112, 39);
            btnSearch.TabIndex = 5;
            btnSearch.TabStop = false;
            btnSearch.Text = "查詢";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // label2
            // 
            label2.Font = new Font("微軟正黑體", 12F);
            label2.Location = new Point(13, 14);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(173, 35);
            label2.TabIndex = 6;
            label2.Text = "請輸入關鍵字 :";
            // 
            // checkBox1
            // 
            checkBox1.Location = new Point(768, 9);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(91, 39);
            checkBox1.TabIndex = 7;
            checkBox1.TabStop = false;
            checkBox1.Text = "排序";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // btnAddToFavorite
            // 
            btnAddToFavorite.Location = new Point(301, 407);
            btnAddToFavorite.Margin = new Padding(4);
            btnAddToFavorite.Name = "btnAddToFavorite";
            btnAddToFavorite.Size = new Size(275, 56);
            btnAddToFavorite.TabIndex = 8;
            btnAddToFavorite.TabStop = false;
            btnAddToFavorite.Text = "收藏";
            btnAddToFavorite.UseVisualStyleBackColor = true;
            btnAddToFavorite.Click += btnAddToFavorite_Click;
            // 
            // FormComic
            // 
            AutoScaleDimensions = new SizeF(14F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(871, 469);
            Controls.Add(btnAddToFavorite);
            Controls.Add(checkBox1);
            Controls.Add(label2);
            Controls.Add(btnSearch);
            Controls.Add(cmbFilterType);
            Controls.Add(txtSearch);
            Controls.Add(dataGridView1);
            Controls.Add(btnGoToRent);
            Controls.Add(btnAddToRent);
            Font = new Font("微軟正黑體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            Margin = new Padding(4);
            MaximizeBox = false;
            Name = "FormComic";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "漫畫資料";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAddToRent;
        private Button btnGoToRent;
        private DataGridView dataGridView1;
        private TextBox txtSearch;
        private ComboBox cmbFilterType;
        private Button btnSearch;
        private Label label2;
        private CheckBox checkBox1;
        private Button btnAddToFavorite;
    }
}