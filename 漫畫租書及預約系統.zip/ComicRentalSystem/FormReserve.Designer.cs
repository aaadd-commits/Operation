﻿namespace ComicRentalSystem
{
    partial class FormReserve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnUnfavorite = new DataGridViewButtonColumn();
            comboSortBy = new ComboBox();
            btnAddToRent = new Button();
            checkBox1 = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { btnUnfavorite });
            dataGridView1.Location = new Point(13, 66);
            dataGridView1.Margin = new Padding(4);
            dataGridView1.MultiSelect = false;
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(971, 508);
            dataGridView1.TabIndex = 3;
            dataGridView1.TabStop = false;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btnUnfavorite
            // 
            btnUnfavorite.HeaderText = "取消收藏";
            btnUnfavorite.MinimumWidth = 8;
            btnUnfavorite.Name = "btnUnfavorite";
            btnUnfavorite.ReadOnly = true;
            btnUnfavorite.UseColumnTextForButtonValue = true;
            btnUnfavorite.Width = 150;
            // 
            // comboSortBy
            // 
            comboSortBy.DropDownStyle = ComboBoxStyle.DropDownList;
            comboSortBy.FormattingEnabled = true;
            comboSortBy.Location = new Point(677, 17);
            comboSortBy.Name = "comboSortBy";
            comboSortBy.Size = new Size(175, 38);
            comboSortBy.TabIndex = 5;
            comboSortBy.TabStop = false;
            comboSortBy.SelectedIndexChanged += comboSortBy_SelectedIndexChanged;
            // 
            // btnAddToRent
            // 
            btnAddToRent.Location = new Point(13, 8);
            btnAddToRent.Margin = new Padding(4);
            btnAddToRent.Name = "btnAddToRent";
            btnAddToRent.Size = new Size(280, 47);
            btnAddToRent.TabIndex = 9;
            btnAddToRent.TabStop = false;
            btnAddToRent.Text = "加入租借清單";
            btnAddToRent.UseVisualStyleBackColor = true;
            btnAddToRent.Click += btnAddToRent_Click;
            // 
            // checkBox1
            // 
            checkBox1.Location = new Point(893, 17);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(91, 39);
            checkBox1.TabIndex = 10;
            checkBox1.TabStop = false;
            checkBox1.Text = "排序";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // FormReserve
            // 
            AutoScaleDimensions = new SizeF(14F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(999, 587);
            Controls.Add(checkBox1);
            Controls.Add(btnAddToRent);
            Controls.Add(comboSortBy);
            Controls.Add(dataGridView1);
            Font = new Font("微軟正黑體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            Margin = new Padding(4);
            MaximizeBox = false;
            Name = "FormReserve";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "漫畫收藏清單";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewButtonColumn btnUnfavorite;
        private ComboBox comboSortBy;
        private Button btnAddToRent;
        private CheckBox checkBox1;
    }
}