﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComicRentalSystem
{
    public class Comic
    {
        [DisplayName("漫畫編號")]
        public string comicID { get; set; }
        [DisplayName("書名")]
        public string Title { get; set; }
        [DisplayName("作者")]
        public string Author { get; set; }
        [DisplayName("庫存數量")]
        public int Count { get; set; }
        [DisplayName("類型")]
        public string Type { get; set; } 
    }
}
