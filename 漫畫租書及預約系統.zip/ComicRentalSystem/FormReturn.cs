﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;

namespace ComicRentalSystem
{
    public partial class FormReturn : Form
    {
        private int clickCount = 0;
        public FormReturn()
        {
            InitializeComponent();
            //固定大小
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Load += FormReturn_Load; // 這樣就能等載入完後才執行
        }

        private void return_data()
        {
            int finePerDay = 10;

            var memberRecords = DataStore.RentalRecords
                .Where(r => r.MemberID == DataStore.CurrentMemberID && r.ReturnDate == null)
                .Select(r =>
                {
                    var days = (DateTime.Today - r.RentDate).Days;
                    var overdue = Math.Max(0, days - r.RentalDays);
                    var fee = overdue * finePerDay;

                    return new
                    {
                        漫畫編號 = r.ComicID,
                        書名 = DataStore.Comics.FirstOrDefault(c => c.comicID == r.ComicID)?.Title ?? "(未知)",
                        已借天數 = days,
                        逾期天數 = overdue,
                        費用 = fee + " 元"
                    };
                }).ToList();
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = memberRecords;
            // ✅ 資料載入後清除預設選取
            dataGridView1.ClearSelection();
            dataGridView1.CurrentCell = null;

        }
        private void FormReturn_Load(object sender, EventArgs e)
        {
            return_data(); // 資料載入並清除選取
        }
        private void btnRemoveSelected_Click_Click(object sender, EventArgs e)
        {
            var records = DataStore.RentalRecords
                .Where(r => r.MemberID == DataStore.CurrentMemberID && r.ReturnDate == null)
                .ToList();

            if (records.Count == 0)
            {
                MessageBox.Show("目前沒有需要歸還的漫畫");
                return;
            }

            // 判斷是否有選擇 DataGridView 中的某一列
            List<RentalRecord> returnTargets = new List<RentalRecord>();
            if (dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    string comicID = row.Cells["漫畫編號"].Value.ToString();
                    var targetRecord = records.FirstOrDefault(r => r.ComicID == comicID);
                    if (targetRecord != null)
                    {
                        returnTargets.Add(targetRecord);
                    }
                }

                if (returnTargets.Count == 0)
                {
                    MessageBox.Show("選擇的資料無法處理，請檢查是否為有效的租借紀錄");
                    return;
                }
            }
            else
            {
                // 若未選擇任何行，則預設歸還全部
                returnTargets = records;
            }

            int totalFee = 0;
            int costPerDay = 10;
            DateTime returnDate = DateTime.Today;
            StringBuilder returnSummary = new StringBuilder();

            foreach (var record in returnTargets)
            {
                record.ReturnDate = returnDate;

                int days = (returnDate - record.RentDate).Days;
                int overdue = Math.Max(0, days - 7);
                int fee = overdue * costPerDay;
                totalFee += fee;

                var comic = DataStore.Comics.FirstOrDefault(c => c.comicID == record.ComicID);
                if (comic != null)
                {
                    comic.Count += 1;
                }

                returnSummary.AppendLine($"● {DataStore.Comics.FirstOrDefault(c => c.comicID == record.ComicID)?.Title ?? "(未知)"}：{days} 天（逾期 {overdue} 天）→ 費用 {fee} 元");
            }

            // 刪除這些已歸還的紀錄
            foreach (var record in returnTargets)
            {
                DataStore.RentalRecords.Remove(record);
            }

            MessageBox.Show($"以下漫畫已成功歸還：\n{returnSummary}\n\n總費用：{totalFee} 元");
            // 歸還成功、庫存增加後
            DataStore.SaveComicsToJson();  // 立即把最新庫存存到 json 檔
            DataStore.SaveRentalRecordsToJson(); //歸還畫面儲存
            // 更新畫面
            return_data();
        }

        private void dataGridView1_MouseUp(object sender, MouseEventArgs e)
        {
            clickCount++;

            if (clickCount % 2 == 0)  // 偶數次點擊
            {
                this.BeginInvoke(new Action(() =>
                {
                    dataGridView1.ClearSelection();
                }));
            }
        }
    }
}
